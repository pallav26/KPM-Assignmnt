# feedback

This project is for feedback form 
download the project and run asp.net core application 
